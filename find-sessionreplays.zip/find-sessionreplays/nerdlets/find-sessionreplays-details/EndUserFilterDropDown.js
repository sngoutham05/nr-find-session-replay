import React from 'react';
import { useState, useEffect, useContext, useMemo } from 'react';
import { PlatformStateContext, navigation } from 'nr1';
import { NrqlQuery, NerdGraphQuery, ngql, Spinner } from 'nr1';
import { Table, TableHeader, TableHeaderCell, TableRow, TableRowCell} from 'nr1';

const EndUserFilterDropDown = ({platformStateDetails, brwsrEntity, onUserSelected}) => {
    //const { accountId, timeRange } = useContext(PlatformStateContext);
    const [selectedUserId, setSelectedUserId] = useState('');

    const END_USER_ID_QUERY = `
    FROM PageAction, BrowserInteraction, AjaxRequest SELECT uniqueCount(session)
    WHERE appName = '${brwsrEntity.name}'
    FACET enduser.id  LIMIT 25
    /* cb: ${platformStateDetails.brwsrEntityUpdTime} */
    `;

    const _convertToItems = (results) => {
        return results.map((result) => ({
            endUserId: result.name,
            numOfSessions: result.results[0].uniqueCount,
            displayUserId: `${result.name} (${result.results[0].uniqueCount})`
        }));
    };

    return (
        <NrqlQuery accountIds={[platformStateDetails.accountId]} query={END_USER_ID_QUERY} 
        timeRange={platformStateDetails.timeRange} formatType={NrqlQuery.FORMAT_TYPE.RAW} >
        {({ data, loading, error }) => {
        //console.log("EndUserFilterDropDown");
            if (loading) return <Spinner inline style={{ margin: '10px 0' }} />;
            //if (error) return <div>Error while fetching data: {error.message}</div>;
            if (data && data.facets && data.facets.length > 0) {
                const endusers = _convertToItems(data.facets);
                //console.log(endusers);
                const updateSelectedUser = (e) => {
                    //console.log(e.target.value);
                    const selectedUserId = e.target.value
                    setSelectedUserId(selectedUserId);
                    if (selectedUserId.trim() === '') {
                        onUserSelected(null);
                    } else {
                        const userDetails = endusers.find(enduser => enduser.displayUserId === selectedUserId);
                        //console.log(userDetails);
                        if (userDetails) {
                            onUserSelected(userDetails);
                        } else {
                            onUserSelected({
                                endUserId : selectedUserId
                            });
                        }
                    }
                };
                return (
                <div class='wnd-FormField wnd-Dropdown wnd-Spacing'>
                    <div class='wnd-FormFieldContent'><div class='wnd-DropdownTrigger'>
                    <input type="text" placeholder="Select a username or type a custom one..."
                    list="username-suggestions" value={selectedUserId}
                    onChange={updateSelectedUser} />
                    <datalist id="username-suggestions">
                        {endusers.map((enduser) => (
                            <option key={enduser.endUserId} value={enduser.displayUserId} />
                        ))}
                    </datalist>
                </div></div></div>
                );
            }

            return <span>No Users found</span>;
            //return <span></span>

        }}
        </NrqlQuery>
    );
}

export default EndUserFilterDropDown
