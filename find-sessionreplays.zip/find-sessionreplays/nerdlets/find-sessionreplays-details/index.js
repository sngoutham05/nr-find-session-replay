import React from 'react';
import { nerdlet, PlatformStateContext } from 'nr1';
import FindSessionReplays from './FindSessionReplays'

// https://docs.newrelic.com/docs/new-relic-programmable-platform-introduction

export default class FindSessionreplaysDetailsNerdlet extends React.Component {
  componentDidMount() {
    nerdlet.setConfig({
      accountPicker: true,
    });
  }  

  render() {
    return (
      <div style={{ padding: '20px', fontSize: '14px' }}>
        <ol>
          <li>Pick an account from the dropdown</li>
          <li>Choose an appropriate time range from the Time range picker</li>
          <li>Select a browser application to display session replays for</li>
          <li>Filter the results by user id (enduser.id)</li>
        </ol>
        <br /><br />
        <PlatformStateContext.Consumer>
          {(platformState) => {
              //console.log(platformState);
              if(platformState.accountId && platformState.accountId !== 'cross-account') {
                return (<FindSessionReplays />);
              }
            }
          }
        </PlatformStateContext.Consumer>        
      </div>
    );
  }
}
