import React from 'react';

// https://docs.newrelic.com/docs/new-relic-programmable-platform-introduction

function FindSessionreplaysDetailsNerdlet() {
  return <h1>Hello, find-sessionreplays-details Nerdlet!</h1>;
}

export default FindSessionreplaysDetailsNerdlet;
