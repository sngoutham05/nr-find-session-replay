import React from 'react';
import { useState, useEffect, useContext, useMemo } from 'react';
import { PlatformStateContext, navigation } from 'nr1';
import { NrqlQuery, NerdGraphQuery, ngql, Spinner } from 'nr1';
import { Table, TableHeader, TableHeaderCell, TableRow, TableRowCell} from 'nr1';

const FetchBrowserSessionReplays = ({platformStateDetails, filters}) => {
  //const { accountId, timeRange } = useContext(PlatformStateContext);

 const BROWSR_FIND_SESSIONREPLAY_SELECT = `FROM PageView, BrowserInteraction, AjaxRequest 
      SELECT earliest(timestamp) as fromTimestamp, latest(timestamp) as untilTimestamp,
      (earliest(pageUrl) or earliest(targetUrl)) as startingUrl, 
      earliest(hasReplay) as hasReplay,
      earliest(deviceType) as deviceType, earliest(userAgentName) as userAgentName, 
      earliest(userAgentVersion) as userAgentVersion, earliest(userAgentOS) as userAgentOS
      `;

  const BROWSR_FIND_SESSIONREPLAY_FACET = `
      FACET appId, appName, entityGuid, enduser.id, session
      ORDER BY max(timestamp)
      `;

  const _displayTimestampInLocalString = (rawTimestamp) => {
    return new Date(rawTimestamp).toLocaleString([], { 
      month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit' 
    });
  };

  const _convertTableItems = (results) => {
    return results.map((result) => ({
      appId: result.name[0],
      appName: result.name[1],
      entityGuid: result.name[2],
      endUserId: result.name[3],
      sessionId: result.name[4],
      displayUserId: result.name[3] ? result.name[3] : 'Unidentified user',
      firstTimestamp: result.results[0].earliest,
      firstTimestampDisplayString: _displayTimestampInLocalString(result.results[0].earliest), 
      lastTimestamp: result.results[1].latest, 
      lastTimestampDisplayString: _displayTimestampInLocalString(result.results[1].latest), 
      startingUrl: result.results[2].earliest, 
      hasReplay: (result.results[3].earliest === true || result.results[3].earliest === 'true') ? 'Yes' : 'No',
      deviceType: result.results[4].earliest,
      userAgentName: result.results[5].earliest, 
      userAgentVersion: result.results[6].earliest,
      userAgentOS: result.results[7].earliest,
    }));
  };

  // Stacked Nerdlet Navigation Manager
  const _openSessionReplay = (e, sessionObj) => {
    e.preventDefault();

    navigation.openStackedNerdlet({
      id: 'session-replay.details-view', 
      urlState: { 
        entityGuid: sessionObj.entityGuid,
        sessionId: sessionObj.sessionId,
        startingUrl: sessionObj.startingUrl,
        urlCapturedReplayFirstTimestamp: sessionObj.firstTimestamp,
        urlCapturedReplayLastTimestamp: sessionObj.lastTimestamp,
        urlCapturedDateNow: Date.now(),
        userId: sessionObj.endUserId
      }
    });
  };

  const _buildSessionReplayQuery = (filters = {}) => {
    const whereClauses = [];
    let limitClause = 50;
    //console.log(filters);
    if(filters.brwsrEntity) {
        whereClauses.push(`appName = '${filters.brwsrEntity.name}'`);
    }
    if(filters.selectedUser) {
        if(filters.selectedUser.displayUserId) {
          whereClauses.push(`enduser.id = '${filters.selectedUser.endUserId}'`);
        } else {
          whereClauses.push(`enduser.id LIKE '%${filters.selectedUser.endUserId}%'`);
        }
        limitClause = 100
    }

    const finalWhereClause = whereClauses.length === 0 ? '' : 
                                        `WHERE ${whereClauses.join(' AND ')}`;
    
    //console.log({finalWhereClause});
    return `${BROWSR_FIND_SESSIONREPLAY_SELECT} ${finalWhereClause} ${BROWSR_FIND_SESSIONREPLAY_FACET} LIMIT ${limitClause}/* cb: ${Date.now()} */`.trim();

  }

  const BROWSR_FIND_SESSIONREPLAY_NRQL = _buildSessionReplayQuery(filters);

  // 4. Return layout markup execution
  return (
    <NrqlQuery accountIds={[platformStateDetails.accountId]} query={BROWSR_FIND_SESSIONREPLAY_NRQL} 
    timeRange={platformStateDetails.timeRange} formatType={NrqlQuery.FORMAT_TYPE.RAW} >
    {({ data, loading, error }) => {
        if (loading) return <Spinner />;
        if (error) return <div>Error while fetching data: {error.message}</div>;
        
        if (data && data.facets && data.facets.length > 0) {
        const sessions = _convertTableItems(data.facets);

        return (
          <div>
            <Table items={sessions} style={{ maxHeight: "400px", overflowY: "auto" }}>
            <TableHeader>
                <TableHeaderCell width='200px'>User ID</TableHeaderCell>
                <TableHeaderCell width='175px'>Session ID</TableHeaderCell>
                <TableHeaderCell width='125px'>Started At</TableHeaderCell>
                <TableHeaderCell width='300px'>Starting Url</TableHeaderCell>
                <TableHeaderCell>Has Replay?</TableHeaderCell>
                <TableHeaderCell>Device Type</TableHeaderCell>
                <TableHeaderCell>User Agent Name</TableHeaderCell>
                <TableHeaderCell>User Agent Version</TableHeaderCell>
                <TableHeaderCell>User Agent OS</TableHeaderCell>
            </TableHeader>

            {({ item }) => (
                <TableRow style={{ height: "60px" }}>
                <TableRowCell>{item.displayUserId}</TableRowCell>
                <TableRowCell>
                    {item.hasReplay === 'Yes' ? (
                    <a 
                        href="#session-details"
                        onClick={(e) => _openSessionReplay(e, item)}
                    >
                        {item.sessionId}
                    </a>
                    ) : (
                    <span>{item.sessionId}</span>
                    )}
                </TableRowCell>
                <TableRowCell>{item.firstTimestampDisplayString}</TableRowCell>
                <TableRowCell>{item.startingUrl}</TableRowCell>
                <TableRowCell>{item.hasReplay}</TableRowCell>
                <TableRowCell>{item.deviceType}</TableRowCell>
                <TableRowCell>{item.userAgentName}</TableRowCell>
                <TableRowCell>{item.userAgentVersion}</TableRowCell>
                <TableRowCell>{item.userAgentOS}</TableRowCell>
                </TableRow>
            )}
            </Table>
            <br />
            <div>Displaying {sessions.length} sessions.</div>
          </div>
        );
        }

        return <div>No sessions found for this timeframe.</div>;
    }}
    </NrqlQuery>
  );
};

export default FetchBrowserSessionReplays;