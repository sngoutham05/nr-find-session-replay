import React from 'react';
import { useState, useEffect, useContext, useMemo } from 'react';
import { PlatformStateContext, EntitiesByNameQuery, Dropdown, DropdownItem, Stack, StackItem, 
    Grid, GridItem, Tile, HeadingText, BlockText, Spinner } from 'nr1';
import FetchBrowserSessionReplays from './FetchBrowserSessionReplays'
import EndUserFilterDropDown from './EndUserFilterDropDown'

const FindSessionReplays = () => {
  const { accountId, timeRange } = useContext(PlatformStateContext);
  const [fetchingEntities, setFetchingEntities] = useState(true);
  const [brwsrApps, setBrwsrApps] = useState([]);
  const [brwsrEntity, setBrwsrEntity] = useState(null);
  /* Using this as a way to force react framework to populate other filters */
  const [brsrEntityChangedTime, setBrsrEntityChangedTime] = useState(Date.now());
  const [selectedUser, setSelectedUser] = useState(null);

  useEffect(() => { 
    setBrwsrApps([]);
    setBrwsrEntity(null);
    setSelectedUser(null);
    getEntitiesByName(accountId);
  }, [accountId]);

  const getEntitiesByName = accountId => {
    if (accountId) {
      // eslint-disable-next-line no-console
      // console.log('Fetching entities for', accountId);
      setFetchingEntities(true);
      const entityTypeFilter = [
        {
          type: 'entityType',
          value: { domain: 'BROWSER', type: 'APPLICATION' }
        },
        {
          type: 'tag',
          value: { key: 'accountId', value: accountId }
        }
      ];

      EntitiesByNameQuery.query({
        name: `%`,
        filters: entityTypeFilter,
        sortType: [EntitiesByNameQuery.SORT_TYPE.NAME]
      }).then(({ data }) => {
        //console.log(data.entities);
        setFetchingEntities(false);
        setBrwsrApps(data?.entities || []);
        setBrwsrEntity(null);
        setBrsrEntityChangedTime(Date.now());
        setSelectedUser(null);
      });
    }
  };

  const activeFilters = useMemo(() => {
    //console.log("activeFilters");
    const filterDetails = {};
    if (brwsrEntity) {
      filterDetails.brwsrEntity = brwsrEntity;
    }
    if (selectedUser) {
      filterDetails.selectedUser = selectedUser;
    }

    //console.log(filterDetails);
    return Object.keys(filterDetails).length === 0 ? null : filterDetails;
  }, [ brwsrEntity, selectedUser ]);

  const _getPlatformState = () => {
    return {
      accountId: accountId,
      timeRange: timeRange,
      brwsrEntityUpdTime: brsrEntityChangedTime
    }
  }

  return (
        <div>
            <HeadingText>Select Filters</HeadingText>
            <br />
            <div style={{ padding: '5px' }}>
                <span style={{ padding: '15px' }}>
                {fetchingEntities ? (
                'Fetching Entities...'
                ) : (
                <Dropdown ariaLabel="Select a browser application"
                    title={brwsrEntity ? brwsrEntity.name : 'Select a browser application'}
                    iconType={Dropdown.ICON_TYPE.HARDWARE_AND_SOFTWARE__SOFTWARE__BROWSER}
                    items={brwsrApps} >
                        {({ item }) => (
                        <DropdownItem key={item.guid}
                            onClick={evt => {
                                //console.log(item);
                                setBrwsrEntity(item);
                                setBrsrEntityChangedTime(Date.now());
                                setSelectedUser(null);
                            }}
                        >
                        {item.name}
                    </DropdownItem>
                    )}
                </Dropdown>
                )}</span>
                <span style={{ padding: '15px', verticalAlign: 'top' }}>
                {brwsrEntity && (<EndUserFilterDropDown platformStateDetails={_getPlatformState()}
                                            brwsrEntity={brwsrEntity}
                                            onUserSelected={(endUser) => setSelectedUser(endUser)}/>)}
                </span>
            </div>
            <br />
            <div style={{ padding: '5px', verticalAlign: 'top'}}>
                {activeFilters && (<FetchBrowserSessionReplays platformStateDetails={_getPlatformState()}
                                        filters={activeFilters} />)}
            </div>
        </div>
    );
};

export default FindSessionReplays;