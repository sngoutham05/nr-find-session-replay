import React from 'react';
import { nerdlet, PlatformStateContext } from 'nr1';
import { Tabs, TabsItem } from 'nr1';
import BrowserFindSessionReplays from './browser/BrowserFindSessionReplays'
import MobileFindSessionReplays from './mobile/MobileFindSessionReplays'

// https://docs.newrelic.com/docs/new-relic-programmable-platform-introduction

export default class FindSessionreplaysDetailsNerdlet extends React.Component {
  componentDidMount() {
    nerdlet.setConfig({
      accountPicker: true,
    });
  }  

  render() {
    return (
      <div style={{ fontSize: '14px' }}>
        <ol style={{ padding: '20px' }}>
          <li>Pick an account from the dropdown</li>
          <li>Choose an appropriate time range from the Time range picker</li>
          <li>Select an application to display session replays for</li>
          <li>Filter the results by user id (enduser.id)</li>
        </ol>
        <PlatformStateContext.Consumer>
          {(platformState) => {
              //console.log(platformState);
              if(platformState.accountId && platformState.accountId !== 'cross-account') {
                //return (<BrowserFindSessionReplays />);
                return (
                  <Tabs defaultValue="browser-tab">
                    <TabsItem value="browser-tab" label="Browser">
                      <BrowserFindSessionReplays />
                    </TabsItem>
                    <TabsItem value="mobile-tab" label="Mobile">
                      <MobileFindSessionReplays />
                    </TabsItem>
                  </Tabs>
                );
              }
            }
          }
        </PlatformStateContext.Consumer>        
      </div>
    );
  }
}
