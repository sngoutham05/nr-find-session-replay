import { useRef, useCallback, useEffect } from 'react';

const useDebouncedCallback = (callback, delay = 300) => {
  const timerRef = useRef(null);
  const callbackRef = useRef(callback);
  callbackRef.current = callback;

  useEffect(() => () => clearTimeout(timerRef.current), []);

  const debounced = useCallback((...args) => {
    clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => callbackRef.current(...args), delay);
  }, [delay]);

  debounced.cancel = () => clearTimeout(timerRef.current);

  return debounced;
};

export default useDebouncedCallback;
