import React from 'react';
import { useState, useEffect, useContext, useMemo } from 'react';
import { PlatformStateContext, navigation } from 'nr1';
import { NrqlQuery, NerdGraphQuery, ngql, Spinner } from 'nr1';
import { Table, TableHeader, TableHeaderCell, TableRow, TableRowCell} from 'nr1';
import useDebouncedCallback from '../common/useDebouncedCallback';
import logger from '../common/logger';

const MobileEndUserFilterDropDown = ({platformStateDetails, mobileEntity, onUserSelected, resetSignal}) => {
    //const { accountId, timeRange } = useContext(PlatformStateContext);
    const [selectedUserId, setSelectedUserId] = useState('');
    const debouncedUserSelected = useDebouncedCallback(onUserSelected, 300);

    useEffect(() => {
        setSelectedUserId('');
        debouncedUserSelected.cancel();
    }, [resetSignal]);

    const MOBILE_END_USER_ID_QUERY = `
    FROM MobileSession, MobileApplicationExit SELECT uniqueCount(sessionId)
    WHERE appName = '${mobileEntity.name}'
    FACET userId  LIMIT 25
    /* cb: ${platformStateDetails.mobileEntityUpdTime} */
    `;

    const _convertToItems = (results) => {
        return results.map((result) => ({
            endUserId: result.name,
            numOfSessions: result.results[0].uniqueCount,
            displayUserId: `${result.name} (${result.results[0].uniqueCount})`
        }));
    };

    const minWidth = 40;
    const _findMaxWidth = (items) => {
        const maxLength = Math.max(...items.map(item => item.displayUserId.length));
        return (minWidth > maxLength) ? `${minWidth}ch` : `${maxLength + 2}ch`;
    };

    return (
        <NrqlQuery accountIds={[platformStateDetails.accountId]} query={MOBILE_END_USER_ID_QUERY} 
        timeRange={platformStateDetails.timeRange} formatType={NrqlQuery.FORMAT_TYPE.RAW} >
        {({ data, loading, error }) => {
        logger.log("EndUserFilterDropDown");
            if (loading) return <Spinner inline style={{ margin: '10px 0' }} />;
            //if (error) return <div>Error while fetching data: {error.message}</div>;
            if (data && data.facets && data.facets.length > 0) {
                const endusers = _convertToItems(data.facets);
                const inputFieldWidth = _findMaxWidth(endusers);

                logger.log(endusers);
                const updateSelectedUser = (e) => {
                    logger.log(e.target.value);
                    const selectedUserId = e.target.value
                    setSelectedUserId(selectedUserId);
                    if (selectedUserId.trim() === '') {
                        debouncedUserSelected(null);
                    } else {
                        const userDetails = endusers.find(enduser => enduser.displayUserId === selectedUserId);
                        logger.log(userDetails);
                        if (userDetails) {
                            debouncedUserSelected(userDetails);
                        } else {
                            debouncedUserSelected({
                                endUserId : selectedUserId
                            });
                        }
                    }
                };
                return (
                <div class='wnd-FormField wnd-Dropdown wnd-Spacing'>
                    <div class='wnd-FormFieldContent'><div class='wnd-DropdownTrigger'>
                    <input type="text" style={{ width: `${inputFieldWidth}`, fontSize: '12px' }} 
                    placeholder="Select a username or type a custom one..."
                    list="mobile-username-suggestions" value={selectedUserId}
                    onChange={updateSelectedUser} />
                    <datalist id="mobile-username-suggestions">
                        {endusers.map((enduser) => (
                            <option key={enduser.endUserId} value={enduser.displayUserId} />
                        ))}
                    </datalist>
                </div></div></div>
                );
            }

            return <span>No Users found</span>;
            //return <span></span>

        }}
        </NrqlQuery>
    );
}

export default MobileEndUserFilterDropDown
