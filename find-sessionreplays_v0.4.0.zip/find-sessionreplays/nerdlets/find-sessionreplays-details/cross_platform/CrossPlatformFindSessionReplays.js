import React from 'react';
import { useState, useEffect, useContext, useMemo } from 'react';
import { PlatformStateContext, EntitiesByNameQuery, Dropdown, DropdownItem, Stack, StackItem, 
    Grid, GridItem, Tile, HeadingText, BlockText, Spinner } from 'nr1';
import BrowserFetchSessionReplayResults from '../browser/BrowserFetchSessionReplayResults'
import BrowserEndUserFilterDropDown from '../browser/BrowserEndUserFilterDropDown'
import MobileEndUserFilterDropDown from '../mobile/MobileEndUserFilterDropDown';
import MobileFetchSessionReplayResults from '../mobile/MobileFetchSessionReplayResults';
import { escapeSingleQuotes } from '../common/StringUtils';
import logger from '../common/logger';

const CrossPlatformFindSessionReplays = () => {
  const { accountId, timeRange } = useContext(PlatformStateContext);
  const [fetchingEntities, setFetchingEntities] = useState(true);
  const [brwsrApps, setBrwsrApps] = useState([]);
  const [brwsrEntity, setBrwsrEntity] = useState(null);
  /* Using this as a way to force react framework to populate other filters */
  const [brwsrEntityChangedTime, setBrwsrEntityChangedTime] = useState(Date.now());
  const [userFromBrwsr, setUserFromBrwsr] = useState(null);

  const [mobileApps, setMobileApps] = useState([]);
  const [mobileEntity, setMobileEntity] = useState(null);
  /* Using this as a way to force react framework to populate other filters */
  const [mobileEntityChangedTime, setMobileEntityChangedTime] = useState(Date.now());
  const [userFromMobile, setUserFromMobile] = useState(null);

  /* Bumped whenever the other platform's user filter changes, so each dropdown can clear its own typed input */
  const [brwsrFilterResetTime, setBrwsrFilterResetTime] = useState(Date.now());
  const [mobileFilterResetTime, setMobileFilterResetTime] = useState(Date.now());


  useEffect(() => { 
    setBrwsrApps([]);
    setBrwsrEntity(null);
    setUserFromBrwsr(null);
    setMobileApps([]);
    setMobileEntity(null);
    setUserFromMobile(null);
    getEntitiesByName(accountId, 'BROWSER');
    getEntitiesByName(accountId, 'MOBILE');
  }, [accountId]);

  const getEntitiesByName = (accountId, domainType) => {
    if (accountId) {
      // eslint-disable-next-line no-console
      logger.log('Fetching entities for', accountId);
      setFetchingEntities(true);
      const entityTypeFilter = [
        {
          type: 'entityType',
          value: { domain: domainType, type: 'APPLICATION' }
        },
        {
          type: 'tag',
          value: { key: 'accountId', value: accountId }
        }
      ];

      EntitiesByNameQuery.query({
        name: `%`,
        filters: entityTypeFilter,
        sortType: [EntitiesByNameQuery.SORT_TYPE.NAME]
      }).then(({ data }) => {
        logger.log(data.entities);
        setFetchingEntities(false);
        if(domainType === 'BROWSER') {
          logger.log('browser apps');
          setBrwsrApps(data?.entities || []);
          setBrwsrEntity(null);
          setBrwsrEntityChangedTime(Date.now());
          setUserFromBrwsr(null);
        } else if (domainType === 'MOBILE') {
          logger.log('mobile apps');
          setMobileApps(data?.entities || []);
          setMobileEntity(null);
          setMobileEntityChangedTime(Date.now());
          setUserFromMobile(null);
        }
      });
    }
  };


  const brwsrSearchFilters = useMemo(() => {
    logger.log("brwsrSearchFilters");
    const searchFilters = [];
    let selectedUser = userFromBrwsr || userFromMobile
    logger.log(selectedUser);
    if(selectedUser) {
        let selectedUserText = escapeSingleQuotes(selectedUser.endUserId);        
        if(selectedUser.displayUserId) {
          searchFilters.push(`enduser.id = '${selectedUserText}'`);
        } else {
          searchFilters.push(`enduser.id LIKE '%${selectedUserText}%'`);
        }
    }
    logger.log(searchFilters); logger.log(searchFilters.length);
    return searchFilters.length === 0 ? null : searchFilters;
  }, [ brwsrEntity, mobileEntity, userFromBrwsr, userFromMobile ]);

  const mobileSearchFilters = useMemo(() => {
    logger.log("mobileSearchFilters");
    const searchFilters = [];
    let selectedUser = userFromBrwsr || userFromMobile
    logger.log(selectedUser);
    if(selectedUser) {
        const selectedUserText = escapeSingleQuotes(selectedUser.endUserId);
        if(selectedUser.displayUserId) {
          searchFilters.push(`userId = '${selectedUserText}'`);
        } else {
          searchFilters.push(`userId LIKE '%${selectedUserText}%'`);
        }
    }
    logger.log(searchFilters); logger.log(searchFilters.length);
    return searchFilters.length === 0 ? null : searchFilters;
  }, [ brwsrEntity, mobileEntity, userFromBrwsr, userFromMobile ]);

  const _getPlatformState = () => {
    return {
      accountId: accountId,
      timeRange: timeRange,
      brwsrEntityUpdTime: brwsrEntityChangedTime,
      mobileEntityChangedTime: mobileEntityChangedTime
    }
  }

  return (
        <div style={{ padding: '15px' }}>
            <HeadingText>Select Filters</HeadingText>
            <br />
            <div>
                <span style={{ padding: '15px 15px 15px 0px' }}>
                {fetchingEntities ? (
                'Fetching Entities...'
                ) : (
                <Dropdown ariaLabel="Select a browser application"
                    title={brwsrEntity ? brwsrEntity.name : 'Select a browser application'}
                    iconType={Dropdown.ICON_TYPE.HARDWARE_AND_SOFTWARE__SOFTWARE__BROWSER}
                    items={brwsrApps} >
                        {({ item }) => (
                        <DropdownItem key={item.guid}
                            onClick={evt => {
                                logger.log(item);
                                setBrwsrEntity(item);
                                setBrwsrEntityChangedTime(Date.now());
                                setUserFromBrwsr(null);
                                setUserFromMobile(null);
                            }}
                        >
                        {item.name}
                    </DropdownItem>
                    )}
                </Dropdown>
                )}</span>
                <span style={{ padding: '15px', verticalAlign: 'top' }}>
                {brwsrEntity && (<BrowserEndUserFilterDropDown platformStateDetails={_getPlatformState()}
                                            brwsrEntity={brwsrEntity}
                                            resetSignal={brwsrFilterResetTime}
                                            onUserSelected={(endUser) => {setUserFromBrwsr(endUser); setUserFromMobile(null); setMobileFilterResetTime(Date.now());}} />)}
                </span>
            </div>
            <br />
            <div>
                <span style={{ padding: '15px 15px 15px 0px' }}>
                {fetchingEntities ? (
                'Fetching Entities...'
                ) : (
                <Dropdown ariaLabel="Select a browser application"
                    title={mobileEntity ? mobileEntity.name : 'Select a mobile application'}
                    iconType={Dropdown.ICON_TYPE.HARDWARE_AND_SOFTWARE__SOFTWARE__MOBILE_APPLICATION}
                    items={mobileApps} >
                        {({ item }) => (
                        <DropdownItem key={item.guid}
                            onClick={evt => {
                                logger.log(item);
                                setMobileEntity(item);
                                setMobileEntityChangedTime(Date.now());
                                setUserFromBrwsr(null);
                                setUserFromMobile(null);
                            }}
                        >
                        {item.name}
                    </DropdownItem>
                    )}
                </Dropdown>
                )}</span>
                <span style={{ padding: '15px', verticalAlign: 'top' }}>
                {mobileEntity && (<MobileEndUserFilterDropDown platformStateDetails={_getPlatformState()}
                                            mobileEntity={mobileEntity}
                                            resetSignal={mobileFilterResetTime}
                                            onUserSelected={(endUser) => {setUserFromMobile(endUser); setUserFromBrwsr(null); setBrwsrFilterResetTime(Date.now());}} />)}
                </span>
            </div>
            <br />
            <div>
                {brwsrSearchFilters && (<BrowserFetchSessionReplayResults platformStateDetails={_getPlatformState()}
                                        searchFilters={brwsrSearchFilters} />)}
            </div>
            <br />
            <div>
                {mobileSearchFilters && (<MobileFetchSessionReplayResults platformStateDetails={_getPlatformState()}
                                        searchFilters={mobileSearchFilters} />)}
            </div>
        </div>
    );
};

export default CrossPlatformFindSessionReplays;