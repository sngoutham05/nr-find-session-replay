import React from 'react';
import { useState, useEffect, useContext, useMemo } from 'react';
import { PlatformStateContext, navigation } from 'nr1';
import { NrqlQuery, NerdGraphQuery, ngql, Spinner } from 'nr1';
import { Table, TableHeader, TableHeaderCell, TableRow, TableRowCell, BlockText} from 'nr1';
import logger from '../common/logger';

const MobileFetchSessionReplayResults = ({platformStateDetails, searchFilters}) => {
  //const { accountId, timeRange } = useContext(PlatformStateContext);

  const MOBILE_FIND_SESSIONREPLAY_SELECT = `FROM MobileSession, MobileApplicationExit, MobileUserAction 
      SELECT earliest(timestamp) as fromTimestamp, latest(timestamp) as untilTimestamp, 
      max(sessionDuration) as sessionDuration, earliest(hasReplay) as hasReplay, 
      earliest(deviceType)  as deviceType, earliest(appVersion) as appVersion
      `;

  const MOBILE_FIND_SESSIONREPLAY_WHERE = `WHERE sessionId IS NOT NULL`;

  const MOBILE_FIND_SESSIONREPLAY_FACET = `
      FACET appId, appName, entityGuid, userId, sessionId
      ORDER BY max(timestamp)
      `;

  const _displayTimestampInLocalString = (rawTimestamp) => {
      return new Date(rawTimestamp).toLocaleString([], { 
      month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit' 
    });
  };

  const _displaySecondsInHumanReadable = (seconds) => {
    const totalSeconds = Number(seconds);
    if (isNaN(totalSeconds) || totalSeconds <= 0) {
        return '0s';
    }

    // Native Date approach to get a fixed "HH:MM:SS" structure
    const timeString = new Date(totalSeconds * 1000).toISOString().slice(11, 19);
    const [h, m, s] = timeString.split(":").map(Number);

    const parts = [];
    if (h > 0) parts.push(`${h}h`);
    if (m > 0 || h > 0) parts.push(`${m}m`);
    if (s > 0 || parts.length === 0) parts.push(`${s}s`);

    return `${parts.join(" ")}`;
  };

  const _convertTableItems = (results) => {
    return results.map((result) => ({
      appId: result.name[0],
      appName: result.name[1],
      entityGuid: result.name[2],
      endUserId: result.name[3],
      displayUserId: result.name[3] ? result.name[3] : 'Unidentified user',
      sessionId: result.name[4],
      firstTimestamp: result.results[0].earliest,
      firstTimestampDisplayString: _displayTimestampInLocalString(result.results[0].earliest), 
      lastTimestamp: result.results[1].latest, 
      lastTimestampDisplayString: _displayTimestampInLocalString(result.results[1].latest),
      sessionDuration: result.results[2].max,
      sessionDurationDisplayString: _displaySecondsInHumanReadable(result.results[2].max),
      hasReplay: (result.results[3].earliest === true || result.results[3].earliest === 'true') ? 'Yes' : 'No',
      deviceType: result.results[4].earliest,
      appVersion: result.results[5].earliest
    }));
  };

  // Stacked Nerdlet Navigation Manager
  const _openSessionReplay = (e, sessionObj) => {
    e.preventDefault();

    navigation.openStackedNerdlet({
      id: 'mobile-session-replay.details-view', 
      urlState: { 
        entityGuid: sessionObj.entityGuid,
        sessionId: sessionObj.sessionId,
        urlCapturedReplayFirstTimestamp: sessionObj.firstTimestamp,
        urlCapturedReplayLastTimestamp: sessionObj.lastTimestamp,
        urlCapturedDateNow: Date.now(),
        userId: sessionObj.endUserId
      }
    });
  };

  const _buildSessionReplayQuery = (searchFilters = []) => {
    const whereClauses = [...searchFilters];
    const limitClause = searchFilters.length > 0 ? 100 : 50;

    const finalWhereClause = whereClauses.length === 0 ? `${MOBILE_FIND_SESSIONREPLAY_WHERE}` :
                                        `${MOBILE_FIND_SESSIONREPLAY_WHERE} AND ${whereClauses.join(' AND ')}`;

    logger.log({finalWhereClause});
    return `${MOBILE_FIND_SESSIONREPLAY_SELECT} ${finalWhereClause} ${MOBILE_FIND_SESSIONREPLAY_FACET} LIMIT ${limitClause} /* cb: ${Date.now()} */`.trim();

  };

  const MOBILE_FIND_SESSIONREPLAY_NRQL = _buildSessionReplayQuery(searchFilters);

  // 4. Return layout markup execution
  return (
    <NrqlQuery accountIds={[platformStateDetails.accountId]} query={MOBILE_FIND_SESSIONREPLAY_NRQL} 
    timeRange={platformStateDetails.timeRange} formatType={NrqlQuery.FORMAT_TYPE.RAW} >
    {({ data, loading, error }) => {
        if (loading) return <Spinner />;
        if (error) return <div>Error while fetching data: {error.message}</div>;
        
        if (data && data.facets && data.facets.length > 0) {
        const sessions = _convertTableItems(data.facets);

        return (
          <div>
            <BlockText>Mobile Sessions: </BlockText>
            <Table items={sessions} style={{ maxHeight: "400px", overflowY: "auto" }}>
            <TableHeader>
                <TableHeaderCell width='300px'>User ID</TableHeaderCell>
                <TableHeaderCell width='400px'>Session ID</TableHeaderCell>
                <TableHeaderCell width='125px'>Started At</TableHeaderCell>
                <TableHeaderCell>Session Duration</TableHeaderCell>
                <TableHeaderCell>Has Replay?</TableHeaderCell>
                <TableHeaderCell>App Version</TableHeaderCell>
                <TableHeaderCell>Device Type</TableHeaderCell>
            </TableHeader>

            {({ item }) => (
                <TableRow style={{ height: "60px" }}>
                <TableRowCell>{item.displayUserId}</TableRowCell>
                <TableRowCell>
                    {item.hasReplay === 'Yes' ? (
                    <a 
                        href="#session-details"
                        onClick={(e) => _openSessionReplay(e, item)}
                    >
                        {item.sessionId}
                    </a>
                    ) : (
                    <span>{item.sessionId}</span>
                    )}
                </TableRowCell>
                <TableRowCell>{item.firstTimestampDisplayString}</TableRowCell>
                <TableRowCell>{item.sessionDurationDisplayString}</TableRowCell>
                <TableRowCell>{item.hasReplay}</TableRowCell>
                <TableRowCell>{item.appVersion}</TableRowCell>
                <TableRowCell>{item.deviceType}</TableRowCell>
                </TableRow>
            )}
            </Table>
            <br />
            <div>Displaying {sessions.length} sessions.</div>
          </div>
        );
        }

        return <div>No Mobile Sessions found for this timeframe.</div>;
    }}
    </NrqlQuery>
  );
};

export default MobileFetchSessionReplayResults;