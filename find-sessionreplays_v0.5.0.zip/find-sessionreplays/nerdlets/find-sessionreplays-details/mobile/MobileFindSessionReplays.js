import React from 'react';
import { useState, useEffect, useContext } from 'react';
import { PlatformStateContext, EntitiesByNameQuery, Dropdown, DropdownItem, Stack, StackItem, 
    Grid, GridItem, Tile, HeadingText, BlockText, Spinner } from 'nr1';
import MobileEndUserFilterDropDown from './MobileEndUserFilterDropDown';
import MobileFetchSessionReplayResults from './MobileFetchSessionReplayResults';
import logger from '../common/logger';
import useSearchFilters from '../common/useSearchFilters';
import { MOBILE_FILTER_KEYS } from '../common/FilterKeys';
import { MOBILE_COLUMNS } from '../common/FilterColumns';

const MobileFindSessionReplays = () => {
  const { accountId, timeRange } = useContext(PlatformStateContext);
  const [fetchingEntities, setFetchingEntities] = useState(true);
  const [mobileApps, setMobileApps] = useState([]);
  const [mobileEntity, setMobileEntity] = useState(null);
  /* Using this as a way to force react framework to populate other filters */
  const [mobileEntityChangedTime, setMobileEntityChangedTime] = useState(Date.now());
  const { searchFilters, setFilter, resetFilters } = useSearchFilters();

  useEffect(() => {
    setMobileApps([]);
    setMobileEntity(null);
    resetFilters();
    getEntitiesByName(accountId);
  }, [accountId]);

  const getEntitiesByName = accountId => {
    if (accountId) {
      // eslint-disable-next-line no-console
      logger.log('Fetching entities for', accountId);
      setFetchingEntities(true);
      const entityTypeFilter = [
        {
          type: 'entityType',
          value: { domain: 'MOBILE', type: 'APPLICATION' }
        },
        {
          type: 'tag',
          value: { key: 'accountId', value: accountId }
        }
      ];

      EntitiesByNameQuery.query({
        name: `%`,
        filters: entityTypeFilter,
        sortType: [EntitiesByNameQuery.SORT_TYPE.NAME]
      }).then(({ data }) => {
        logger.log(data.entities);
        setFetchingEntities(false);
        setMobileApps(data?.entities || []);
        setMobileEntity(null);
        setMobileEntityChangedTime(Date.now());
        resetFilters();
      });
    }
  };

  const _getPlatformState = () => {
    return {
      accountId: accountId,
      timeRange: timeRange,
      mobileEntityUpdTime: mobileEntityChangedTime
    }
  }

  return (
        <div style={{ padding: '15px' }}>
            <HeadingText>Select Filters</HeadingText>
            <br />
            <div>
                <span style={{ padding: '15px 15px 15px 0px' }}>
                {fetchingEntities ? (
                'Fetching Entities...'
                ) : (
                <Dropdown ariaLabel="Select a browser application"
                    title={mobileEntity ? mobileEntity.name : 'Select a mobile application'}
                    iconType={Dropdown.ICON_TYPE.HARDWARE_AND_SOFTWARE__SOFTWARE__MOBILE_APPLICATION}
                    items={mobileApps} >
                        {({ item }) => (
                        <DropdownItem key={item.guid}
                            onClick={evt => {
                                logger.log(item);
                                setMobileEntity(item);
                                setMobileEntityChangedTime(Date.now());
                                resetFilters();
                                setFilter(MOBILE_FILTER_KEYS.APP_NAME, `${MOBILE_COLUMNS.APP_NAME} = '${item.name}'`);
                            }}
                        >
                        {item.name}
                    </DropdownItem>
                    )}
                </Dropdown>
                )}</span>
                <span style={{ padding: '15px', verticalAlign: 'top' }}>
                {mobileEntity && (<MobileEndUserFilterDropDown platformStateDetails={_getPlatformState()}
                                            mobileEntity={mobileEntity}
                                            setFilter={setFilter}/>)}
                </span>
            </div>
            <br />
            <div>
                {searchFilters && (<MobileFetchSessionReplayResults platformStateDetails={_getPlatformState()}
                                        searchFilters={searchFilters} />)}
            </div>
        </div>
    );
};

export default MobileFindSessionReplays;