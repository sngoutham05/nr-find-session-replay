if (typeof window !== 'undefined' && typeof window.__SR_DEBUG__ === 'undefined') {
  window.__SR_DEBUG__ = false;
}

const isDebugEnabled = () => typeof window !== 'undefined' && window.__SR_DEBUG__ === true;

const noop = () => {};

const logger = {
  get log() { return isDebugEnabled() ? console.log.bind(console) : noop; },
  get warn() { return isDebugEnabled() ? console.warn.bind(console) : noop; },
  get error() { return isDebugEnabled() ? console.error.bind(console) : noop; },
};

export default logger;
