export const BROWSER_COLUMNS = {
  APP_NAME: 'appName',
  END_USER_ID: 'enduser.id',
};

export const MOBILE_COLUMNS = {
  APP_NAME: 'appName',
  END_USER_ID: 'userId',
};
