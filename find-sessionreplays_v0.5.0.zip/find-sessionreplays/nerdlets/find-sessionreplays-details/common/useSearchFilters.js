import { useState, useCallback, useMemo } from 'react';

const useSearchFilters = () => {
  const [filtersByKey, setFiltersByKey] = useState({});

  const setFilter = useCallback((key, clause) => {
    setFiltersByKey(prev => {
      if (!clause) {
        if (!(key in prev)) return prev;
        const next = { ...prev };
        delete next[key];
        return next;
      }
      if (prev[key] === clause) return prev;
      return { ...prev, [key]: clause };
    });
  }, []);

  const clearFilter = useCallback((key) => setFilter(key, null), [setFilter]);

  const resetFilters = useCallback(() => setFiltersByKey({}), []);

  const searchFilters = useMemo(() => {
    const values = Object.values(filtersByKey);
    return values.length > 0 ? values : null;
  }, [filtersByKey]);

  return { searchFilters, setFilter, clearFilter, resetFilters };
};

export default useSearchFilters;
