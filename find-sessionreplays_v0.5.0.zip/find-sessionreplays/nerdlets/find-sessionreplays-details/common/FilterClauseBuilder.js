import { escapeSingleQuotes } from './StringUtils';

export const buildExactOrLikeClause = (column, rawValue, isExactMatch) => {
  if (!rawValue) {
    return null;
  }

  const escapedValue = escapeSingleQuotes(rawValue);
  return isExactMatch
    ? `${column} = '${escapedValue}'`
    : `${column} LIKE '%${escapedValue}%'`;
};
