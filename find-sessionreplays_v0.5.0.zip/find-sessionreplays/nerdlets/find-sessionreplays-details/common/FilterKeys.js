export const BROWSER_FILTER_KEYS = {
  APP_NAME: 'browser.appName',
  END_USER: 'browser.endUser',
};

export const MOBILE_FILTER_KEYS = {
  APP_NAME: 'mobile.appName',
  END_USER: 'mobile.endUser',
};
