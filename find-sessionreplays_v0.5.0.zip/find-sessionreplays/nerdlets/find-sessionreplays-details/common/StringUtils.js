export const escapeSingleQuotes = (text) => {
    if(text) {
        return text.replaceAll("'", "\\\'");
    }

    return "";
};

