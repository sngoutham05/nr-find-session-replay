import { FILTER_MIRRORS } from './FilterMirrorConfig';

const findMirror = (key) => FILTER_MIRRORS.find(m => m.browserKey === key || m.mobileKey === key);

export const mirrorFilter = (ownFilters, otherFilters, key, clause) => {
  ownFilters.setFilter(key, clause);

  const mirror = findMirror(key);
  if (!mirror) return;

  const isBrowserSource = mirror.browserKey === key;
  const sourceColumn = isBrowserSource ? mirror.browserColumn : mirror.mobileColumn;
  const targetColumn = isBrowserSource ? mirror.mobileColumn : mirror.browserColumn;
  const otherKey = isBrowserSource ? mirror.mobileKey : mirror.browserKey;
  const mirroredClause = (clause && sourceColumn !== targetColumn) ? clause.replace(sourceColumn, targetColumn) : clause;
  otherFilters.setFilter(otherKey, mirroredClause);
};
