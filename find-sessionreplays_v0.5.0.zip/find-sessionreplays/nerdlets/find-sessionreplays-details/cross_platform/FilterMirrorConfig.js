import { BROWSER_FILTER_KEYS, MOBILE_FILTER_KEYS } from '../common/FilterKeys';
import { BROWSER_COLUMNS, MOBILE_COLUMNS } from '../common/FilterColumns';

export const FILTER_MIRRORS = [
  { browserKey: BROWSER_FILTER_KEYS.END_USER, browserColumn: BROWSER_COLUMNS.END_USER_ID,
    mobileKey: MOBILE_FILTER_KEYS.END_USER,   mobileColumn: MOBILE_COLUMNS.END_USER_ID },
  // future mirrored filters: add a row here only, no other file needs to change
];
