import React from 'react';
import { useState, useEffect, useContext } from 'react';
import { PlatformStateContext, EntitiesByNameQuery, Dropdown, DropdownItem, Stack, StackItem, 
    Grid, GridItem, Tile, HeadingText, BlockText, Spinner } from 'nr1';
import BrowserFetchSessionReplayResults from '../browser/BrowserFetchSessionReplayResults'
import BrowserEndUserFilterDropDown from '../browser/BrowserEndUserFilterDropDown'
import MobileEndUserFilterDropDown from '../mobile/MobileEndUserFilterDropDown';
import MobileFetchSessionReplayResults from '../mobile/MobileFetchSessionReplayResults';
import logger from '../common/logger';
import useSearchFilters from '../common/useSearchFilters';
import { mirrorFilter } from './FilterMirrors';

const CrossPlatformFindSessionReplays = () => {
  const { accountId, timeRange } = useContext(PlatformStateContext);
  const [fetchingEntities, setFetchingEntities] = useState(true);
  const [brwsrApps, setBrwsrApps] = useState([]);
  const [brwsrEntity, setBrwsrEntity] = useState(null);
  /* Using this as a way to force react framework to populate other filters */
  const [brwsrEntityChangedTime, setBrwsrEntityChangedTime] = useState(Date.now());

  const [mobileApps, setMobileApps] = useState([]);
  const [mobileEntity, setMobileEntity] = useState(null);
  /* Using this as a way to force react framework to populate other filters */
  const [mobileEntityChangedTime, setMobileEntityChangedTime] = useState(Date.now());

  const browserFilters = useSearchFilters();
  const mobileFilters = useSearchFilters();

  /* Bumped whenever the other platform's user filter changes, so each dropdown can clear its own typed input */
  const [brwsrFilterResetTime, setBrwsrFilterResetTime] = useState(Date.now());
  const [mobileFilterResetTime, setMobileFilterResetTime] = useState(Date.now());

  const handleBrowserUserFilterChange = (key, clause) => {
    mirrorFilter(browserFilters, mobileFilters, key, clause);
    setMobileFilterResetTime(Date.now());
  };

  const handleMobileUserFilterChange = (key, clause) => {
    mirrorFilter(mobileFilters, browserFilters, key, clause);
    setBrwsrFilterResetTime(Date.now());
  };

  useEffect(() => {
    setBrwsrApps([]);
    setBrwsrEntity(null);
    browserFilters.resetFilters();
    setMobileApps([]);
    setMobileEntity(null);
    mobileFilters.resetFilters();
    getEntitiesByName(accountId, 'BROWSER');
    getEntitiesByName(accountId, 'MOBILE');
  }, [accountId]);

  const getEntitiesByName = (accountId, domainType) => {
    if (accountId) {
      // eslint-disable-next-line no-console
      logger.log('Fetching entities for', accountId);
      setFetchingEntities(true);
      const entityTypeFilter = [
        {
          type: 'entityType',
          value: { domain: domainType, type: 'APPLICATION' }
        },
        {
          type: 'tag',
          value: { key: 'accountId', value: accountId }
        }
      ];

      EntitiesByNameQuery.query({
        name: `%`,
        filters: entityTypeFilter,
        sortType: [EntitiesByNameQuery.SORT_TYPE.NAME]
      }).then(({ data }) => {
        logger.log(data.entities);
        setFetchingEntities(false);
        if(domainType === 'BROWSER') {
          logger.log('browser apps');
          setBrwsrApps(data?.entities || []);
          setBrwsrEntity(null);
          setBrwsrEntityChangedTime(Date.now());
          browserFilters.resetFilters();
        } else if (domainType === 'MOBILE') {
          logger.log('mobile apps');
          setMobileApps(data?.entities || []);
          setMobileEntity(null);
          setMobileEntityChangedTime(Date.now());
          mobileFilters.resetFilters();
        }
      });
    }
  };

  const _getPlatformState = () => {
    return {
      accountId: accountId,
      timeRange: timeRange,
      brwsrEntityUpdTime: brwsrEntityChangedTime,
      mobileEntityChangedTime: mobileEntityChangedTime
    }
  }

  return (
        <div style={{ padding: '15px' }}>
            <HeadingText>Select Filters</HeadingText>
            <br />
            <div>
                <span style={{ padding: '15px 15px 15px 0px' }}>
                {fetchingEntities ? (
                'Fetching Entities...'
                ) : (
                <Dropdown ariaLabel="Select a browser application"
                    title={brwsrEntity ? brwsrEntity.name : 'Select a browser application'}
                    iconType={Dropdown.ICON_TYPE.HARDWARE_AND_SOFTWARE__SOFTWARE__BROWSER}
                    items={brwsrApps} >
                        {({ item }) => (
                        <DropdownItem key={item.guid}
                            onClick={evt => {
                                logger.log(item);
                                setBrwsrEntity(item);
                                setBrwsrEntityChangedTime(Date.now());
                                browserFilters.resetFilters();
                                mobileFilters.resetFilters();
                            }}
                        >
                        {item.name}
                    </DropdownItem>
                    )}
                </Dropdown>
                )}</span>
                <span style={{ padding: '15px', verticalAlign: 'top' }}>
                {brwsrEntity && (<BrowserEndUserFilterDropDown platformStateDetails={_getPlatformState()}
                                            brwsrEntity={brwsrEntity}
                                            resetSignal={brwsrFilterResetTime}
                                            setFilter={handleBrowserUserFilterChange} />)}
                </span>
            </div>
            <br />
            <div>
                <span style={{ padding: '15px 15px 15px 0px' }}>
                {fetchingEntities ? (
                'Fetching Entities...'
                ) : (
                <Dropdown ariaLabel="Select a browser application"
                    title={mobileEntity ? mobileEntity.name : 'Select a mobile application'}
                    iconType={Dropdown.ICON_TYPE.HARDWARE_AND_SOFTWARE__SOFTWARE__MOBILE_APPLICATION}
                    items={mobileApps} >
                        {({ item }) => (
                        <DropdownItem key={item.guid}
                            onClick={evt => {
                                logger.log(item);
                                setMobileEntity(item);
                                setMobileEntityChangedTime(Date.now());
                                browserFilters.resetFilters();
                                mobileFilters.resetFilters();
                            }}
                        >
                        {item.name}
                    </DropdownItem>
                    )}
                </Dropdown>
                )}</span>
                <span style={{ padding: '15px', verticalAlign: 'top' }}>
                {mobileEntity && (<MobileEndUserFilterDropDown platformStateDetails={_getPlatformState()}
                                            mobileEntity={mobileEntity}
                                            resetSignal={mobileFilterResetTime}
                                            setFilter={handleMobileUserFilterChange} />)}
                </span>
            </div>
            <br />
            <div>
                {browserFilters.searchFilters && (<BrowserFetchSessionReplayResults platformStateDetails={_getPlatformState()}
                                        searchFilters={browserFilters.searchFilters} />)}
            </div>
            <br />
            <div>
                {mobileFilters.searchFilters && (<MobileFetchSessionReplayResults platformStateDetails={_getPlatformState()}
                                        searchFilters={mobileFilters.searchFilters} />)}
            </div>
        </div>
    );
};

export default CrossPlatformFindSessionReplays;