import React from 'react';
import { useState, useEffect, useContext } from 'react';
import { PlatformStateContext, EntitiesByNameQuery, Dropdown, DropdownItem, Stack, StackItem, 
    Grid, GridItem, Tile, HeadingText, BlockText, Spinner } from 'nr1';
import BrowserFetchSessionReplayResults from './BrowserFetchSessionReplayResults'
import BrowserEndUserFilterDropDown from './BrowserEndUserFilterDropDown'
import BrowserAjaxRequestFilter from './BrowserAjaxRequestFilter'
import logger from '../common/logger';
import useSearchFilters from '../common/useSearchFilters';
import { BROWSER_FILTER_KEYS } from '../common/FilterKeys';
import { BROWSER_COLUMNS } from '../common/FilterColumns';

const BrowserFindSessionReplays = () => {
  const { accountId, timeRange } = useContext(PlatformStateContext);
  const [fetchingEntities, setFetchingEntities] = useState(true);
  const [brwsrApps, setBrwsrApps] = useState([]);
  const [brwsrEntity, setBrwsrEntity] = useState(null);
  /* Using this as a way to force react framework to populate other filters */
  const [brsrEntityChangedTime, setBrsrEntityChangedTime] = useState(Date.now());
  const { searchFilters, setFilter, resetFilters } = useSearchFilters();

  useEffect(() => {
    setBrwsrApps([]);
    setBrwsrEntity(null);
    resetFilters();
    getEntitiesByName(accountId);
  }, [accountId]);

  const getEntitiesByName = accountId => {
    if (accountId) {
      // eslint-disable-next-line no-console
      logger.log('Fetching entities for', accountId);
      setFetchingEntities(true);
      const entityTypeFilter = [
        {
          type: 'entityType',
          value: { domain: 'BROWSER', type: 'APPLICATION' }
        },
        {
          type: 'tag',
          value: { key: 'accountId', value: accountId }
        }
      ];

      EntitiesByNameQuery.query({
        name: `%`,
        filters: entityTypeFilter,
        sortType: [EntitiesByNameQuery.SORT_TYPE.NAME]
      }).then(({ data }) => {
        logger.log(data.entities);
        setFetchingEntities(false);
        setBrwsrApps(data?.entities || []);
        setBrwsrEntity(null);
        setBrsrEntityChangedTime(Date.now());
        resetFilters();
      });
    }
  };

  const _getPlatformState = () => {
    return {
      accountId: accountId,
      timeRange: timeRange,
      brwsrEntityUpdTime: brsrEntityChangedTime
    }
  }

  return (
        <div style={{ padding: '15px' }}>
            <HeadingText>Select Filters</HeadingText>
            <br />
            <div>
                <span style={{ padding: '15px 15px 15px 0px' }}>
                {fetchingEntities ? (
                'Fetching Entities...'
                ) : (
                <Dropdown ariaLabel="Select a browser application"
                    title={brwsrEntity ? brwsrEntity.name : 'Select a browser application'}
                    iconType={Dropdown.ICON_TYPE.HARDWARE_AND_SOFTWARE__SOFTWARE__BROWSER}
                    items={brwsrApps} >
                        {({ item }) => (
                        <DropdownItem key={item.guid}
                            onClick={evt => {
                                logger.log(item);
                                setBrwsrEntity(item);
                                setBrsrEntityChangedTime(Date.now());
                                resetFilters();
                                setFilter(BROWSER_FILTER_KEYS.APP_NAME, `${BROWSER_COLUMNS.APP_NAME} = '${item.name}'`);
                            }}
                        >
                        {item.name}
                    </DropdownItem>
                    )}
                </Dropdown>
                )}</span>
                <span style={{ padding: '15px', verticalAlign: 'top' }}>
                {brwsrEntity && (<BrowserEndUserFilterDropDown platformStateDetails={_getPlatformState()}
                                            brwsrEntity={brwsrEntity}
                                            setFilter={setFilter}/>)}
                {/* </span><br />
                <span style={{ padding: '15px', verticalAlign: 'top' }}>
                {brwsrEntity && (<BrowserAjaxRequestFilter platformStateDetails={_getPlatformState()}
                                            brwsrEntity={brwsrEntity}
                                            setFilter={setFilter}/>)}
                */}
                </span>
            </div>
            <br />
            <div>
                {searchFilters && (<BrowserFetchSessionReplayResults platformStateDetails={_getPlatformState()}
                                        searchFilters={searchFilters} />)}
            </div>
        </div>
    );
};

export default BrowserFindSessionReplays;