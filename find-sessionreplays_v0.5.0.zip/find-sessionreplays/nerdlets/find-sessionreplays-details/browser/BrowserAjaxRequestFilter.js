import React from 'react';
import { useState, useEffect, useContext, useMemo } from 'react';
import { PlatformStateContext, navigation } from 'nr1';
import { NrqlQuery, NerdGraphQuery, ngql, Spinner } from 'nr1';
import { Table, TableHeader, TableHeaderCell, TableRow, TableRowCell, BlockText} from 'nr1';
import logger from '../common/logger';

const BrowserAjaxRequestFilter = ({platformStateDetails, brwsrEntity, onUserSelected}) => {
    const [gqlOperationName, setGqlOperationName] = useState('');

    const GRAPHQL_FILTER_QUERY = `
    FROM AjaxRequest SELECT uniques(operationName) AS graphQLOperations WHERE operationFramework = 'GraphQL'
    AND appName = '${brwsrEntity.name}' LIMIT MAX
    /* cb: ${platformStateDetails.brwsrEntityUpdTime} */
    `;

    const minWidth = 25;
    const _findMaxWidth = (items) => {
        const maxLength = Math.max(...items.map(item => item.length));
        //return `${maxLength + 2}ch`;
        return (minWidth > maxLength) ? `${minWidth}ch` : `${maxLength + 2}ch`;
    };

    return (
        <span>
            <BlockText>Ajax Request Filters: </BlockText>
            <NrqlQuery accountIds={[platformStateDetails.accountId]} query={GRAPHQL_FILTER_QUERY} 
            timeRange={platformStateDetails.timeRange} formatType={NrqlQuery.FORMAT_TYPE.RAW} >
            {({ data, loading, error }) => {
                if (loading) return <Spinner inline style={{ margin: '10px 0' }} />;
                //if (error) return <div>Error while fetching data: {error.message}</div>;
                if (data && data.results && data.results.length > 0 && data.results[0] 
                                        && data.results[0].members && data.results[0].members.length > 0) {
                    logger.log(data.results[0].members);
                    const gqlOperations = data.results[0].members;
                    const inputFieldWidth = _findMaxWidth(gqlOperations);

                    const updateGqlOperationName = (e) => {
                        logger.log(e.target.value);
                        const gqlOpName = e.target.value;
                        setGqlOperationName(gqlOpName);
                    };
                    return (
                        <div class='wnd-FormField wnd-Dropdown wnd-Spacing' style={{ padding: '10px', paddingLeft: '0px'}}>
                            <div class='wnd-FormFieldContent'><div class='wnd-DropdownTrigger'>
                            <input type="text" style={{ width: `${inputFieldWidth}` }} 
                            placeholder="Select a GraphQL operation name or type a custom one..."
                            list="brwsr-ajax-graphql-operation-name-list" value={gqlOperationName}
                            onChange={updateGqlOperationName} />
                            <datalist id="brwsr-ajax-graphql-operation-name-list">
                                {gqlOperations.map((gqlOpName) => (
                                    <option key={gqlOpName} value={gqlOpName} />
                                ))}
                            </datalist>
                        </div></div></div>
                    );
                }

                //return <span>No GraphQL Operations found</span>;
                return <span></span>

            }}
            </NrqlQuery>
        </span>
    );
}

export default BrowserAjaxRequestFilter
